#include<bits/stdc++.h>
using i64 = long long;
using ll = long long;
using uint = unsigned int;
using ull = unsigned long long;

using namespace std;


void solve()
{
    constexpr int n = 26;
    constexpr int T = 1e5 / 26;
    constexpr int inf = 1e9;
    constexpr int up = 91;
    cout<<T<<endl;
    for(int i = 0;i < T;i++){
        cout<<n<<' '<<5<<endl;
        for(int j = 0;j < 6;j++){
            int x = 1 << j;
            cout<<x<<" "<<inf - x<<endl;
        }
        for(int j = 0;j < 7;j++){
            cout<<up<<" "<<inf - up<<endl;
        }

        for(int j = 0;j < 6;j++){
            int x = 1 << j;
            cout<<inf - x<<" "<<x<<endl;
        }
        for(int j = 0;j < 7;j++){
            cout<<inf - up<<" "<<up<<endl;
        }
    }
}

int main()
{
    std::ios::sync_with_stdio(0);
    std::cin.tie(0);
    int tt = 1;
    //cin >> tt;
    while(tt--){
        solve();
    }
    return 0;
}