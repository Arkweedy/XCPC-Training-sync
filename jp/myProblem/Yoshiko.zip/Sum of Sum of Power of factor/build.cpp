#include <iostream>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <string>
#include <vector>
#include <random>
using namespace std;


int main() {
    srand(time(0)); // 初始化随机种子
    system("g++ -std=c++23 makedata.cpp -o makedata.exe");
    system("makedata.exe");
    return 0;
}